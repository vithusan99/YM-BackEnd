package com.Makket.demo.Repository;


import java.util.List;
//import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.Makket.demo.Model.Product;
import com.Makket.demo.Model.Shipping;

@Repository
public interface ProductRepository extends MongoRepository <Product, String> {


	List<Product> findByProduct(String product);

	@Query("{$or: [ { 'product': { $regex: ?0 , $options: 'i' } }, { 'price': { $regex: ?0 , $options: 'i' } } , { 'category':{ $regex: ?0, $options: 'i' } },{ 'type': { $regex: ?0 , $options: 'i' } } ]}")
	List<Product> findBySearchContaining(String searched);





}
