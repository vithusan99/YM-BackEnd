//package com.Makket.demo.Model;
//
//import org.springframework.data.mongodb.core.mapping.Document;
//
//@Document(collection="Wshipping")
//public class Wshipping {
//
//	@Id
//	private String id;
//	
//}
